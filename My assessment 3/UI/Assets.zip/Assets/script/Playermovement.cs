﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Playermovement : MonoBehaviour
{
    public float speed1;
    public float speed2;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Input.GetAxis("Vertical") * Time.deltaTime * speed1, 0, Input.GetAxis("Horizontal") * Time.deltaTime * speed1);
        transform.Rotate(0, Input.GetAxis("Rotate") * Time.deltaTime * speed2, 0); 

    }
}
